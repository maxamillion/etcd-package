#!/bin/sh

curl -L http://127.0.0.1:4001/v1/keys/message -d value="Hello world"
