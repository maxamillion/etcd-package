package server

const ReleaseVersion = "0.4.5"
